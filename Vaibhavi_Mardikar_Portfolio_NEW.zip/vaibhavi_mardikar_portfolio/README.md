# Vaibhavi Vijay Mardikar — Developer Portfolio

A responsive personal portfolio website built with HTML, CSS, and a small amount of JavaScript.

## Files
- `index.html` — page content and sections
- `styles.css` — responsive dark navy/blue styling
- `script.js` — mobile navigation and current footer year
- `assets/vaibhavi-profile.png` — uploaded profile photo

## Preview
Extract the ZIP, then open `index.html` in a modern browser. No build tools or dependencies are required.

## Before publishing
- Review all text and contact information.
- If you later want to add GitHub, resume, or certificate verification links, add only real URLs you control.
- For public hosting, upload the entire folder while preserving the `assets` folder structure.

## Sections
Home, About, Skills, Projects, Achievements, Certificates, Education, Contact.

The EDUSPHERE description is intentionally framed as a prototype and does not claim a production blockchain deployment.
